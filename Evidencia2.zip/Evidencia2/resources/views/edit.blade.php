<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar libro</title>
</head>
<body>

<div class="container">
    <h1>Modificar libro</h1>
    <form action="{{ route('books.update', $book->id) }}" method="POST">
        @csrf
        @method('PUT')
        <label for="title">Título:</label>
        <input type="text" name="title" id="title" value="{{ $book->title }}">

        <label for="author">Autor:</label>
        <input type="text" name="author" id="author" value="{{ $book->author }}">

        <button type="submit">Modificar</button>
    </form>
</div>

</body>
</html>
