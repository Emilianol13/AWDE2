<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Book; // Asegúrate de importar el modelo de Book

class BookController extends Controller
{
    //TOTAL DE LIBROS IMPLICADOS
    public function index()
    {
        $books = Book::all();
        return view('books.index', ['books' => $books]);
    }

    //FORMULARIO DE CREACIÓN DE LIBROS
    public function create()
    {
        return view('books.create');
    }

    //ALMACENAMIENTO DE LOS DATOS DE UN NUEVO LIBRO CREADO
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'title' => 'required',
            'author_name' => 'required',
            'isbn' => 'required',
            'published_year' => 'required|integer',
        ]);

        Book::create($validatedData);

        return redirect()->route('books.index')->with('success', 'Libro creado correctamente');
    }

    //VISUALIZACIÓN DE LOS DETALLES DE UN LIBRO ESPECÍFICO 
    public function show(Book $book)
    {
        return view('books.show', ['book' => $book]);
    }

    //VISUALIZACIÓN DE UN LIBRO ESPECÍFICO CON BASE A SUS DETALLES
    public function edit(Book $book)
    {
        return view('books.edit', ['book' => $book]);
    }

    //ACTUALIZACIÓN DEL LIBRO DENTRO DE LA DB
    public function update(Request $request, Book $book)
    {
        $validatedData = $request->validate([
            'title' => 'required',
            'author_name' => 'required',
            'isbn' => 'required',
            'published_year' => 'required|integer',
        ]);

        $book->update($validatedData);

        return redirect()->route('books.index')->with('success', 'Libro actualizado correctamente');
    }

    //ELIMINACIÓN DE UN LIBRO DENTRO DE LA DB
    public function destroy(Book $book)
    {
        $book->delete();

        return redirect()->route('books.index')->with('success', 'Libro eliminado correctamente');
    }
}
